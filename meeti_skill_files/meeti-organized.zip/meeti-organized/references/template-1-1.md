# 1-1 Meeting Template

## Purpose
Focus on career development, personal growth, feedback exchange, and relationship building between two individuals (typically manager-report, peer-to-peer, or mentor-mentee).

## Template Structure

```markdown
# [Meeting Title - 1-1 Between Attendee Names]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [Person 1], [Person 2]

## Meeting Goal

[One or two sentences describing the purpose of the 1-1, deduced from title and content]

## Discussion Summary

[Organized summary of key topics discussed, grouped by theme. Clean up speech artifacts while preserving all important information.]

### [Topic 1]
[Summary]

### [Topic 2]
[Summary]

## Career Development Discussion

[Capture any career-related discussions including:]
- Growth opportunities discussed
- Skill development areas identified
- Career progression plans or timelines
- Training or learning opportunities mentioned
- Promotion considerations or readiness discussions
- Role changes or new responsibilities discussed

*[If no career development was discussed, write: "No career development topics discussed during this meeting."]*

## Feedback Exchanged

### Feedback Given to [Person 1]
- **[Feedback Category]:** [Specific feedback provided]
- **[Feedback Category]:** [Specific feedback provided]

### Feedback Given to [Person 2]
- **[Feedback Category]:** [Specific feedback provided]
- **[Feedback Category]:** [Specific feedback provided]

*[If no feedback was exchanged, write: "No formal feedback exchanged during this meeting."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Concerns Raised

- **[Concern Title]:** [Description and context]

*[If no concerns were raised, write: "No concerns raised during this meeting."]*

## Follow-up Items

- [Items that need clarification or future discussion]
- [Questions raised but not fully answered]
- [Topics deferred for next 1-1]

*[If no follow-up items, write: "No follow-up items for next meeting."]*
```

## Processing Guidelines for 1-1s

- **Career Development Focus:** Look for discussions about growth, promotion, skill development, career goals, aspirations, challenges, and opportunities
- **Feedback Identification:** Extract both positive reinforcement and constructive feedback. Note who gave feedback to whom
- **Relationship Context:** Pay attention to working relationship discussions, communication preferences, and support needs
- **Privacy Sensitivity:** Handle personal or sensitive topics with appropriate discretion in the summary
