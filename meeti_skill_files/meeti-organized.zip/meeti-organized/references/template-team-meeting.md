# Team Meeting Template

## Purpose
Standard format for general team discussions, planning sessions, retrospectives, and collaborative decision-making.

## Template Structure

```markdown
# [Meeting Title]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [List of participants]

## Meeting Goal

[One or two sentences describing the purpose and objective of the meeting, deduced from both the title and the discussion content]

## Discussion Summary

[Organized summary of the key topics discussed. Clean up filler words, incomplete sentences, and speaking artifacts while preserving all important information. Group related topics together and use clear subsections if the meeting covered multiple themes]

### [Topic 1]
[Summary of discussion points]

### [Topic 2]
[Summary of discussion points]

## Decisions Made

- **[Decision Title]:** [What was decided, who made the decision, and any context about why this decision was made]
- **[Decision Title]:** [What was decided, who made the decision, and any context about why this decision was made]

*[If no decisions were made, write: "No formal decisions made during this meeting."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Blockers & Concerns

- **[Blocker/Concern Title]:** [Description and context]
- **[Blocker/Concern Title]:** [Description and context]

*[If no blockers or concerns were raised, write: "No blockers or concerns raised during this meeting."]*

## Parking Lot / Items Needing Clarification

- [Vague or incomplete statements that seemed important but need follow-up]
- [Questions raised but not fully answered]
- [Topics that were mentioned but deferred for later discussion]

*[If no items need clarification, write: "No items for the parking lot."]*
```

## Processing Guidelines for Team Meetings

### Decision Documentation

Team meetings often involve collaborative decision-making. Pay special attention to:

- **Explicit decisions:** When someone says "let's go with option X" or "we've decided to..."
- **Implicit consensus:** When the team agrees on a direction even without formal language
- **Decision rationale:** Capture why decisions were made, not just what was decided
- **Decision owners:** Note who has accountability for the decision

### Discussion Organization

- **Group by theme:** Don't summarize chronologically. Related topics should be together
- **Extract key points:** Focus on substance, not conversational back-and-forth
- **Note disagreements:** If there was healthy debate, capture different perspectives briefly
- **Highlight conclusions:** Make it clear what the team landed on for each topic

### Meeting Types Using This Template

This template works well for:
- General team meetings
- Planning sessions (sprint planning, roadmap planning)
- Retrospectives
- Feature discussions
- Project kickoffs
- Status updates
- Brainstorming sessions

### Special Considerations

- **Retrospectives:** The "Discussion Summary" section can be structured around "What went well," "What didn't go well," and "Action items for improvement"
- **Planning sessions:** Focus on decisions made and action items with clear timelines
- **Brainstorming:** The "Discussion Summary" can list ideas generated, with the "Decisions Made" section capturing which ideas the team wants to pursue
