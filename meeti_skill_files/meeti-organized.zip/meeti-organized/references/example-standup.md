# Stand-up Meeting Example

This example demonstrates how to process a daily team stand-up meeting with health check assessment.

## Input Transcript

```
[9:00 AM] Scrum Master: Good morning team! Let's do our stand-up. Alex, want to start?

[9:00 AM] Alex: Sure. Yesterday I wrapped up the user authentication refactoring. Today I'm starting on the API rate limiting feature. No blockers.

[9:01 AM] Scrum Master: Nice! Jordan?

[9:01 AM] Jordan: Um, I'm still working on the database migration script. It's taking longer than expected because I found some data inconsistencies that need to be cleaned up first. I might need help understanding the old schema.

[9:02 AM] Alex: I can help with that! I worked on that system last year. Want to sync after standup?

[9:02 AM] Jordan: That would be great, thanks!

[9:03 AM] Scrum Master: Perfect. Sam, how about you?

[9:03 AM] Sam: Yesterday I finished the UI components for the dashboard. Today I'm blocked though - I need the API endpoints that Alex is working on to be ready before I can integrate.

[9:04 AM] Alex: Oh, the rate limiting endpoints? Those won't be done until Thursday at least.

[9:04 AM] Sam: Hmm, that's later than I thought. That pushes my timeline back.

[9:05 AM] Scrum Master: Let's chat after standup about reprioritizing your work, Sam. Maybe you can pick up something else in the meantime?

[9:05 AM] Sam: Yeah, that makes sense.

[9:06 AM] Scrum Master: Anything else from anyone?

[9:06 AM] Jordan: Just wondering - are we still planning to demo this sprint's work on Friday?

[9:07 AM] Scrum Master: Good question. Let me confirm with the product team and get back to everyone. Anything else?

[9:07 AM] Team: Nope, all good!

[9:08 AM] Scrum Master: Great, thanks everyone!
```

## Meeti-Advanced Output

```markdown
# Daily Team Stand-up

**Date:** [Date from context]
**Duration:** 8 minutes
**Attendees:** Scrum Master, Alex, Jordan, Sam

## Stand-up Health Check: 🟡 YELLOW

**Health Status Reasoning:**
This stand-up receives a Yellow (OKish) status for the following reasons:
- One team member (Sam) discovered an unexpected dependency that blocks their planned work and pushes back their timeline
- Data inconsistencies found during Jordan's work were not previously known, suggesting some surprise technical issues
- Good team collaboration (Alex offering to help Jordan) but overall indicates some planning gaps
- Sprint demo status is unclear, adding uncertainty to team goals
- While the stand-up was efficient and blockers are being addressed, the unexpected dependencies and timeline impacts indicate less-than-ideal team alignment and planning

## Meeting Goal

Quick daily synchronization to share progress updates, identify blockers, and coordinate team activities.

## Discussion Summary

### Individual Updates

**Alex**
- **Completed:** User authentication refactoring
- **In Progress:** Starting API rate limiting feature
- **Notes:** Rate limiting endpoints expected to be complete by Thursday

**Jordan**
- **Completed:** Continued work on database migration script
- **In Progress:** Still working on database migration, taking longer than expected
- **Notes:** Found unexpected data inconsistencies requiring cleanup before proceeding. Needs help understanding old database schema

**Sam**
- **Completed:** UI components for dashboard
- **In Progress:** Blocked waiting for API endpoints
- **Notes:** Expected API endpoints won't be ready until Thursday, which pushes Sam's timeline back

### Team Collaboration Highlights

- **Alex helped Jordan:** Alex offered to help Jordan understand the old database schema, having worked on that system last year. Sync scheduled for after stand-up

## Blockers & Dependencies

- **Sam blocked by API dependencies:** Sam cannot integrate dashboard UI components until Alex completes rate limiting API endpoints (expected Thursday). This dependency was not previously known and pushes Sam's timeline back
- **Data inconsistencies in database migration:** Jordan discovered data inconsistencies that must be cleaned up before completing the migration script, extending the timeline

## Concerns Raised

- **Timeline impact for Sam:** Unexpected delay in API endpoint availability pushes back Sam's integration work
- **Sprint demo uncertainty:** Team is unsure if sprint demo is still scheduled for Friday, creating ambiguity about sprint goals

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| Complete API rate limiting feature | Alex | Thursday |
| Sync with Jordan on old database schema | Alex | After stand-up |
| Confirm sprint demo schedule with product team | Scrum Master | TBD |
| Discuss work reprioritization with Sam | Scrum Master | After stand-up |
| Continue database migration with data cleanup | Jordan | TBD |

## Parking Lot

- Work reprioritization for Sam while waiting for API dependencies (to be discussed after stand-up)
- Sprint demo confirmation and scheduling details
```

## Key Observations

- **Health Check Assessment**: Yellow (OKish) status assigned based on unexpected blockers, dependencies, and planning gaps
- **Detailed reasoning**: Health status includes specific evidence from the stand-up to justify the assessment
- **Collaboration captured**: Alex offering help to Jordan is highlighted as positive team dynamic
- **Unexpected discoveries**: Both data inconsistencies and API dependency timing were surprises, indicating planning issues
- **Multiple action types**: Includes immediate tasks (sync after stand-up), ongoing work, and confirmation requests
- **Parking lot usage**: Items deferred for post-stand-up discussion are properly captured
- **Honest assessment**: Despite good team collaboration, the Yellow status reflects real issues that need attention
