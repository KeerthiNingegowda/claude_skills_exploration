# Stand-up Meeting Template

## Purpose
Quick daily synchronization to share progress, identify blockers, coordinate team activities, and assess overall team health.

## Template Structure

```markdown
# [Meeting Title - Daily Stand-up / Sprint Stand-up]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [List of participants]

## Stand-up Health Check: [🔴 RED / 🟡 YELLOW / 🟢 GREEN]

**Health Status Reasoning:**
[Explain why this health status was assigned. Consider:]
- Severity and number of blockers
- Team velocity and progress
- Unexpected issues or surprises
- Dependencies between team members
- Overall team coordination and alignment

**Health Status Guidelines:**
- **🟢 GREEN (Good):** Team is making expected progress, no significant blockers, good coordination, on track for goals
- **🟡 YELLOW (OKish):** Some blockers or delays present, minor coordination issues, progress slower than ideal but manageable
- **🔴 RED (Concerning):** Significant blockers, multiple team members blocked, poor coordination, at risk of missing goals, urgent attention needed

## Meeting Goal

[One or two sentences describing the purpose - typically daily sync and coordination]

## Discussion Summary

### Individual Updates

**[Team Member 1]**
- **Completed:** [What they finished]
- **In Progress:** [What they're working on]
- **Notes:** [Any relevant context or timeline information]

**[Team Member 2]**
- **Completed:** [What they finished]
- **In Progress:** [What they're working on]
- **Notes:** [Any relevant context or timeline information]

### Team Collaboration Highlights

[Document any positive collaboration moments:]
- Team members helping each other
- Knowledge sharing
- Efficient problem-solving
- Good coordination

*[If no notable collaboration occurred, omit this section]*

## Blockers & Dependencies

- **[Blocker/Dependency Title]:** [Description, impact, and who/what is blocked. Note if this is an unexpected blocker or a known dependency]

*[If no blockers, write: "No blockers identified during this stand-up."]*

## Concerns Raised

- **[Concern Title]:** [Description and context]

*[If no concerns, write: "No concerns raised during this stand-up."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Parking Lot

- [Items deferred for later discussion]
- [Questions or topics that came up but weren't fully addressed]
- [Follow-up conversations needed outside of stand-up]

*[If no parking lot items, write: "No items for the parking lot."]*
```

## Processing Guidelines for Stand-ups

### Health Check Assessment

Be honest and realistic when assessing stand-up health. Consider:

**RED (Concerning) indicators:**
- Multiple team members blocked
- Critical dependencies preventing work
- Significant unexpected issues discovered
- Team at risk of missing sprint/milestone goals
- Poor coordination or communication breakdown

**YELLOW (OKish) indicators:**
- One or two blockers that have workarounds
- Minor delays or slowdowns
- Some unexpected issues but manageable
- Dependencies causing timeline adjustments
- Coordination could be better

**GREEN (Good) indicators:**
- Team making expected progress
- No significant blockers
- Good coordination and communication
- On track for goals
- Proactive identification of potential issues

### Stand-up Specific Notes

- **Keep it Brief:** Stand-ups are meant to be quick. Summarize efficiently
- **Focus on Blockers:** These are the most critical items to capture
- **Dependencies Matter:** Document when team members are waiting on each other
- **Parking Lot Usage:** Stand-ups often surface topics that need deeper discussion. Capture these for follow-up
- **Health Trends:** Consider mentioning if health status changed from previous stand-ups (if known from context)
