---
name: meeti-organized
description: Advanced meeting transcript summarization with specialized templates for different meeting types. Provides customized formatting for 1-1s (career development focus), Knowledge Transfers (technical handoff documentation), Stand-ups (health check analysis), and Team Meetings (standard format). Use when you need meeting-specific structured outputs with enhanced context and specialized insights.
---

# Meeti-Advanced - Meeting-Type Specific Transcript Summarizer

Meeti-advanced extends the base meeti skill with specialized templates and processing logic tailored to specific meeting types. Each meeting type has its own output format optimized for its unique purpose and content.

## Supported Meeting Types

1. **1-1 Meetings** - Career development, feedback, manager check-ins
2. **Knowledge Transfer Sessions** - Technical handoffs, training, onboarding
3. **Stand-ups** - Daily syncs, sprint planning, progress updates
4. **Team Meetings** - General team discussions, planning, retrospectives

## Processing Workflow

1. **Identify meeting type** from context, title, or explicit user instruction
2. **Read appropriate template** from references/ directory based on meeting type
3. **Read entire transcript** and extract metadata
4. **Apply meeting-type specific processing** using the template
5. **Format output** according to meeting type specifications

## Meeting Type Templates

Load the appropriate template based on the meeting type:

- **1-1 Meetings**: Read `references/template-1-1.md`
  - Focus: Career development, feedback exchange, relationship building
  - Special sections: Career Development Discussion, Feedback Exchanged

- **Knowledge Transfer Sessions**: Read `references/template-knowledge-transfer.md`
  - Focus: Technical documentation, historical context, reusable reference material
  - Special sections: Historical Context (Technology/Product/People), Tips & Tricks, Resources

- **Stand-ups**: Read `references/template-standup.md`
  - Focus: Health check analysis, blockers, team coordination
  - Special sections: Stand-up Health Check (Red/Yellow/Green), Dependencies

- **Team Meetings**: Read `references/template-team-meeting.md`
  - Focus: Standard meeting notes, decisions, action items
  - Special sections: Decisions Made, standard format

## Core Principles (All Meeting Types)

These principles apply universally:

1. **Metadata**: Always capture title, attendees, and duration
2. **Goal Deduction**: Deduce meeting goals from title and discussion content
3. **Clean Speech**: Remove filler words ("um," "uh") and incoherence while preserving meaning
4. **Vague Statements**: Reorganize unclear statements into appropriate sections (don't ignore)
5. **Action Items**: Always document with owner and due date. Use "TBD" for missing information
6. **Concerns**: Always capture concerns raised during the meeting

## Examples

For detailed examples showing how to apply templates:

- `references/example-knowledge-transfer.md` - Technical handoff session
- `references/example-standup.md` - Daily team stand-up with health check

Load examples only when you need clarification on how to process a specific meeting type.

## Quick Tips

1. **Let meeting type drive format** - Don't force templates across types
2. **Capture context, not just content** - Especially for knowledge transfers, explain why things exist
3. **Be realistic with assessments** - Honest health checks help teams improve
4. **Use TBD liberally** - Better to capture action items with TBD than lose them
5. **Reorganize, don't regurgitate** - Transform vague statements into clear, actionable items
6. **Focus on utility** - Notes should be useful references, not just meeting records
