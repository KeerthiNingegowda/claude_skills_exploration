---
name: meeti-advanced
description: Advanced meeting transcript summarization with specialized templates for different meeting types. Provides customized formatting for 1-1s (career development focus), Knowledge Transfers (technical handoff documentation), Stand-ups (health check analysis), and Team Meetings (standard format). Use when you need meeting-specific structured outputs with enhanced context and specialized insights.
---

# Meeti-Advanced - Meeting-Type Specific Transcript Summarizer

Meeti-advanced extends the base meeti skill with specialized templates and processing logic tailored to specific meeting types. Each meeting type has its own output format optimized for its unique purpose and content.

## Supported Meeting Types

1. **1-1 Meetings** - Career development, feedback, manager check-ins
2. **Knowledge Transfer Sessions** - Technical handoffs, training, onboarding
3. **Stand-ups** - Daily syncs, sprint planning, progress updates
4. **Team Meetings** - General team discussions, planning, retrospectives

## Base Principles (Applied to All Meeting Types)

These principles apply across all meeting types:

1. **Meeting Metadata:** Always capture title, attendees, and duration
2. **Goal Deduction:** Deduce meeting goals from both the title and discussion content
3. **Discussion Summarization:** Remove filler words and speech incoherence while preserving all meaningful content
4. **Vague Statement Handling:** Important but unclear statements should be organized and added to appropriate sections (not ignored)
5. **Action Items:** Always document with owner and due date. Use "TBD" for missing information rather than omitting the action item
6. **Concerns Documentation:** Always capture any concerns raised during the meeting

## Processing Workflow

1. **Identify meeting type** from context, title, or explicit user instruction
2. **Read and analyze** the entire transcript
3. **Extract metadata** (title, attendees, duration)
4. **Apply meeting-type specific processing** using the appropriate template
5. **Format output** according to meeting type specifications

---

## Meeting Type 1: 1-1 Meetings

### Purpose
Focus on career development, personal growth, feedback exchange, and relationship building between two individuals (typically manager-report, peer-to-peer, or mentor-mentee).

### Template Structure

```markdown
# [Meeting Title - 1-1 Between Attendee Names]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [Person 1], [Person 2]

## Meeting Goal

[One or two sentences describing the purpose of the 1-1, deduced from title and content]

## Discussion Summary

[Organized summary of key topics discussed, grouped by theme. Clean up speech artifacts while preserving all important information.]

### [Topic 1]
[Summary]

### [Topic 2]
[Summary]

## Career Development Discussion

[Capture any career-related discussions including:]
- Growth opportunities discussed
- Skill development areas identified
- Career progression plans or timelines
- Training or learning opportunities mentioned
- Promotion considerations or readiness discussions
- Role changes or new responsibilities discussed

*[If no career development was discussed, write: "No career development topics discussed during this meeting."]*

## Feedback Exchanged

### Feedback Given to [Person 1]
- **[Feedback Category]:** [Specific feedback provided]
- **[Feedback Category]:** [Specific feedback provided]

### Feedback Given to [Person 2]
- **[Feedback Category]:** [Specific feedback provided]
- **[Feedback Category]:** [Specific feedback provided]

*[If no feedback was exchanged, write: "No formal feedback exchanged during this meeting."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Concerns Raised

- **[Concern Title]:** [Description and context]

*[If no concerns were raised, write: "No concerns raised during this meeting."]*

## Follow-up Items

- [Items that need clarification or future discussion]
- [Questions raised but not fully answered]
- [Topics deferred for next 1-1]

*[If no follow-up items, write: "No follow-up items for next meeting."]*
```

### Processing Guidelines for 1-1s

- **Career Development Focus:** Look for discussions about growth, promotion, skill development, career goals, aspirations, challenges, and opportunities
- **Feedback Identification:** Extract both positive reinforcement and constructive feedback. Note who gave feedback to whom
- **Relationship Context:** Pay attention to working relationship discussions, communication preferences, and support needs
- **Privacy Sensitivity:** Handle personal or sensitive topics with appropriate discretion in the summary

---

## Meeting Type 2: Knowledge Transfer Sessions

### Purpose
Document technical handoffs, training sessions, and onboarding knowledge sharing to create reusable reference material for future use.

### Template Structure

```markdown
# [Knowledge Transfer Session Title]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Led by:** [Primary knowledge sharer]
**Attendees:** [List of participants receiving knowledge]

## Session Goal

[Clear statement of what knowledge is being transferred and why]

## Knowledge Transfer Summary

[Comprehensive but concise summary organized by topic. Include historical context and practical insights. Avoid verbosity while ensuring completeness.]

### Historical Context

**Technology Perspective**
[How this system/feature/process evolved technically. What decisions were made and why. What technologies are involved and their purpose.]

**Product Perspective**
[How this fits into the product strategy. What business problems it solves. How customers/users interact with it. Key product decisions that influenced the technical approach.]

**People Perspective**
[Who built this originally. Which teams are involved. Who to contact for different aspects. Any organizational context that matters for maintaining or extending this work.]

### Technical Deep Dive

[Detailed technical information organized by components, systems, or processes. Include:]
- Architecture and design patterns
- Key components and their interactions
- Data flows and dependencies
- Configuration and environment details
- Code structure and important files/modules

### Tips, Tricks & Friction Points

**Best Practices**
- [Recommended approaches and proven patterns]
- [Tools and shortcuts that make work easier]
- [Things to do for optimal results]

**Common Friction Points**
- **[Friction Point]:** [Description and recommended handling approach]
- **[Friction Point]:** [Description and recommended handling approach]

**Gotchas to Avoid**
- [Common mistakes or traps]
- [Edge cases that cause problems]
- [Things that aren't obvious but are important]

### Resources & References

**Documentation**
- [Link or reference to relevant documentation]
- [Internal wiki pages or guides]

**Code Repositories**
- [Repository links with brief descriptions]

**Tools & Dashboards**
- [Monitoring dashboards]
- [Development tools]
- [Testing environments]

**Key Contacts**
- **[Name]:** [Area of expertise / when to contact]
- **[Name]:** [Area of expertise / when to contact]

**Additional Resources**
- [Any other shared materials, examples, or references]

*[If no resources were shared, write: "No specific resources were shared during this session."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Questions & Clarifications Needed

- [Questions raised but not fully answered]
- [Areas that need additional documentation]
- [Topics to revisit in follow-up sessions]

*[If no clarifications needed, write: "No outstanding questions or clarifications."]*
```

### Processing Guidelines for Knowledge Transfers

- **Focus on the Knowledge Sharer:** Clearly identify who led the session, as this person is the primary resource
- **Organize for Future Reference:** Structure information so someone can use these notes to understand the topic without having been in the meeting
- **Capture Context:** Historical context (technology, product, people) is crucial for understanding current state and making future decisions
- **Practical Focus:** Emphasize tips, tricks, and friction points that aren't usually in formal documentation
- **Resource Collection:** The resources checklist should be comprehensive and immediately usable
- **Avoid Verbosity:** Be thorough but concise. If the transfer was short and straightforward, don't artificially inflate the notes

---

## Meeting Type 3: Stand-ups

### Purpose
Quick daily synchronization with health monitoring to ensure team alignment, identify blockers, and assess overall team effectiveness.

### Template Structure

```markdown
# [Stand-up Meeting Title]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [List of participants]

## Stand-up Health Check: [🟢 GREEN / 🟡 YELLOW / 🔴 RED]

**Health Status Reasoning:**
[Clear explanation of why this health status was assigned. Consider:]
- Team members' clarity on their work and goals
- Number and severity of blockers or dependencies
- Surprise elements that emerged (unexpected blockers, unclear priorities)
- Quality of collaboration and information sharing
- Whether the stand-up achieved its purpose efficiently

## Meeting Goal

[Brief statement of the stand-up's purpose - typically quick status sync and blocker identification]

## Discussion Summary

### Individual Updates

**[Person 1]**
- **Completed:** [What they finished]
- **In Progress:** [What they're working on today]
- **Notes:** [Any relevant context or updates]

**[Person 2]**
- **Completed:** [What they finished]
- **In Progress:** [What they're working on today]
- **Notes:** [Any relevant context or updates]

### Team Collaboration Highlights

[Document instances where team members helped each other, shared knowledge, or coordinated effectively]
- **[Person A] helped [Person B]:** [Brief description of assistance provided]
- **[Coordination between teams/people]:** [Description]

*[If no collaboration highlights, write: "No specific collaboration highlights during this stand-up."]*

## Blockers & Dependencies

- **[Blocker/Dependency Title]:** [Description, who is affected, and any planned resolution]
- **[Blocker/Dependency Title]:** [Description, who is affected, and any planned resolution]

*[If no blockers, write: "No blockers or dependencies reported."]*

## Concerns Raised

- **[Concern Title]:** [Description and context]

*[If no concerns were raised, write: "No concerns raised during this stand-up."]*

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

*[If no action items emerged, write: "No action items from this stand-up."]*

## Parking Lot

- [Topics mentioned that need separate discussion]
- [Items that were cut short due to time]
- [Questions or issues that need follow-up outside stand-up]

*[If no parking lot items, write: "No items for the parking lot."]*
```

### Health Check Status Definitions

**🟢 GREEN (Good Stand-up)**
- All team members have clarity on their work
- Minimal or expected blockers that have clear resolution paths
- Good team collaboration and information sharing
- Stand-up was efficient and valuable
- No major surprises or confusion

**🟡 YELLOW (OKish Stand-up)**
- Some uncertainty about priorities or work direction
- Blockers exist but are being addressed
- Some unexpected dependencies emerged
- Stand-up was somewhat lengthy or unfocused
- Team alignment could be better

**🔴 RED (Problematic Stand-up)**
- Significant confusion about priorities or goals
- Multiple blocking issues with no clear resolution
- Many unexpected problems or dependencies surfaced
- Stand-up was inefficient or failed to provide value
- Poor team alignment or communication
- Indicates need for broader team discussion or intervention

### Processing Guidelines for Stand-ups

- **Health Check is Critical:** Always provide a health status with detailed reasoning. This helps leadership identify when teams need support
- **Watch for Patterns:** Note when the same types of blockers appear repeatedly
- **Collaboration Matters:** Highlighting instances where people helped each other reinforces positive team culture
- **Parking Lot Discipline:** Capture items that shouldn't be discussed in detail during stand-up
- **Surprise Factor:** Unexpected blockers or unclear priorities are red flags for health status
- **Efficiency Assessment:** A stand-up that runs long without clear value should impact health status

---

## Meeting Type 4: Team Meetings

### Purpose
General team discussions, planning sessions, retrospectives, and broader team coordination. Uses the standard meeti skill template without customization.

### Template Structure

Use the standard meeti skill template:

```markdown
# [Meeting Title]

**Date:** [Meeting Date if available]
**Duration:** [Meeting Duration]
**Attendees:** [List of participants]

## Meeting Goal

[One or two sentences describing the purpose and objective of the meeting]

## Discussion Summary

[Organized summary of key topics discussed. Group related topics together.]

### [Topic 1]
[Summary of discussion points]

### [Topic 2]
[Summary of discussion points]

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| [Specific task description] | [Person's name] | [Date or "TBD"] |

## Blockers & Concerns

- **[Blocker/Concern Title]:** [Description and context]

*[If no blockers or concerns were raised, write: "No blockers or concerns raised during this meeting."]*

## Parking Lot / Items Needing Clarification

- [Vague or incomplete statements that need follow-up]
- [Questions raised but not fully answered]
- [Topics deferred for later discussion]

*[If no items need clarification, write: "No items for the parking lot."]*
```

### Processing Guidelines for Team Meetings

Refer to the standard meeti skill processing guidelines. No special customization is needed for general team meetings.

---

## General Processing Guidelines (All Meeting Types)

### Handling Speech Artifacts

- **Remove filler words:** "um," "uh," "you know," "like" (when used as fillers)
- **Clean up false starts:** Where speakers restart sentences
- **Fix incoherent fragments:** Infer intended meaning from context
- **Preserve meaning:** Even when cleaning up language
- **Maintain speaker intent:** While making text readable

### Deducing Action Items

Look for:
- **Commitment language:** "I will," "I'll handle," "Let me," "I can do"
- **Assignments:** "Could you," "Can [name] take care of," "[Name] will"
- **Deadlines:** "by Friday," "next week," "before the release"

Mark as **"TBD"** when:
- No specific owner is mentioned but task is clear
- No deadline is mentioned or implied
- Assignment is tentative or needs confirmation

### Identifying Concerns

Document items that:
- Raise risks or uncertainties
- Express potential problems
- Indicate resource constraints
- Need escalation or decision-making
- Show confusion or lack of clarity

### Important Vague Statements

Don't ignore vague sentences if they seem important. Instead:
- Reorganize them to be clearer
- Place them in appropriate sections (Parking Lot, Follow-up Items, Clarifications Needed)
- Provide context about why they might be important
- Flag if they need follow-up

---

## Usage Instructions

When using this skill:

1. **Identify the meeting type** from the transcript, title, or user instruction
2. **Apply the appropriate template** based on meeting type
3. **Follow the base principles** for all meetings
4. **Use meeting-specific guidelines** for enhanced processing
5. **Verify completeness** using the quality checklist

If meeting type is unclear, analyze the content:
- Discussions about personal growth, feedback → 1-1
- Technical teaching, system explanations, handoffs → Knowledge Transfer
- Quick daily updates, brief status shares → Stand-up
- Everything else → Team Meeting

---

## Quality Checklist

Before finalizing meeting notes, verify:

**Base Requirements (All Meeting Types)**
- [ ] All attendee names are captured
- [ ] Meeting duration is calculated or noted
- [ ] Meeting goal clearly reflects the purpose
- [ ] Discussion summary is organized by topic, not chronologically
- [ ] All action items identified with owners and due dates (or TBD)
- [ ] Concerns are documented with sufficient context
- [ ] Important vague statements are captured and organized appropriately
- [ ] Language is professional and coherent
- [ ] No filler words or artifacts remain

**Meeting-Specific Requirements**

**For 1-1s:**
- [ ] Career development discussions are captured (if any)
- [ ] Feedback is attributed correctly (who gave feedback to whom)
- [ ] Follow-up items are documented

**For Knowledge Transfers:**
- [ ] Knowledge sharer is clearly identified
- [ ] Historical context (technology, product, people) is included
- [ ] Tips, tricks, and friction points are documented
- [ ] Resources checklist is comprehensive and usable
- [ ] Summary is thorough but not unnecessarily verbose

**For Stand-ups:**
- [ ] Health check status is assigned with clear reasoning
- [ ] Collaboration highlights are captured
- [ ] Blockers and dependencies are documented
- [ ] Parking lot items are identified

**For Team Meetings:**
- [ ] Standard meeti format is followed correctly

---

## Example: 1-1 Meeting

**Input Transcript:**
```
[2:00 PM] Manager: Hey! Thanks for making time today. How are things going?

[2:01 PM] Report: Pretty good overall! I finished the mobile app feature we talked about last time. It's in code review now.

[2:02 PM] Manager: That's great! I saw the PR. The code quality looks really solid. You've been, um, really improving your testing practices.

[2:03 PM] Report: Thanks! I've been working on that. So I wanted to talk about something. I've been doing a lot of frontend work lately, and I'm wondering if there might be opportunities to do more backend development?

[2:04 PM] Manager: Yeah, absolutely. We actually have a new API project starting next quarter. I was thinking you'd be a good fit for it. It would involve working with the platform team pretty closely.

[2:05 PM] Report: That sounds interesting! What would I need to prepare?

[2:05 PM] Manager: Probably brush up on your Go skills - that's what we're using. And maybe familiarize yourself with our microservices architecture. I can send you some docs.

[2:06 PM] Report: Perfect. I'll start looking into that.

[2:07 PM] Manager: One thing I wanted to mention - you've been doing great with the technical work, but I'd love to see you take more initiative in team discussions. You know, like sharing your ideas more in planning meetings.

[2:08 PM] Report: Yeah, you're right. I've been a bit quiet. I'll work on that.

[2:08 PM] Manager: No pressure, but I think your perspective would be really valuable. Anything else on your mind?

[2:09 PM] Report: Not really. Oh, actually - I'm blocked on getting access to the analytics database. Can you help with that?

[2:09 PM] Manager: Sure, I'll follow up with IT today. Should have that sorted by tomorrow.

[2:10 PM] Report: Thanks! That's all from me.

[2:10 PM] Manager: Cool. Same time next week?

[2:10 PM] Report: Works for me!
```

**Meeti-Advanced Output:**
```markdown
# 1-1 Between Manager and Report

**Date:** [Date from context]
**Duration:** 10 minutes
**Attendees:** Manager, Report

## Meeting Goal

Regular check-in to discuss current work progress, career development opportunities, exchange feedback, and address any blockers or concerns.

## Discussion Summary

### Current Work Status

Report completed the mobile app feature and submitted it for code review. Manager reviewed the pull request and noted solid code quality.

### Career Development Discussion

Report expressed interest in expanding beyond frontend work to include more backend development opportunities. Manager identified an upcoming API project starting next quarter that would be a good fit, involving close collaboration with the platform team.

### Preparation and Learning

Report needs to brush up on Go programming language and become familiar with the microservices architecture to prepare for the backend opportunity. Manager will provide relevant documentation.

## Career Development Discussion

- **Backend Development Opportunity:** Report expressed desire to expand skills beyond frontend work. Manager identified new API project starting next quarter as growth opportunity
- **Skill Development Areas:** Need to develop Go programming skills and understanding of microservices architecture
- **Team Collaboration:** Report will work closely with platform team on upcoming project
- **Timeline:** Project starts next quarter, giving time for skill preparation

## Feedback Exchanged

### Feedback Given to Report
- **Positive - Code Quality:** Testing practices have shown significant improvement. Code quality on recent mobile app feature is solid
- **Development Area - Team Participation:** Encouraged to take more initiative in team discussions and share ideas during planning meetings. Manager noted Report's perspective would add value to team conversations

### Feedback Given to Manager
No formal feedback provided to Manager during this meeting.

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| Send microservices architecture documentation | Manager | TBD |
| Study Go programming language | Report | Before next quarter |
| Review microservices architecture documentation | Report | Before next quarter |
| Follow up with IT on analytics database access | Manager | Tomorrow |
| Take more initiative in team discussions | Report | Ongoing |

## Concerns Raised

- **Database Access Blocker:** Report is blocked waiting for analytics database access. Manager will follow up with IT to resolve.

## Follow-up Items

- Schedule next 1-1 for same time next week
- Track progress on Go learning and backend preparation in future check-ins
```

---

## Example: Knowledge Transfer Session

**Input Transcript:**
```
[10:00 AM] Senior Dev: Alright, let's get started. Today I'm going to walk you through our payment processing system. This is, um, one of our most critical services.

[10:01 AM] New Dev: Thanks for doing this! I'm excited to learn about it.

[10:02 AM] Senior Dev: So, quick background - we built this about two years ago when we were migrating away from a third-party solution. The old system was too expensive and didn't give us enough control.

[10:03 AM] New Dev: What third-party were we using before?

[10:03 AM] Senior Dev: It was Stripe, actually. Still a great service, but for our volume, it made sense to bring it in-house. The product team really wanted more flexibility for different payment methods too.

[10:04 AM] Senior Dev: The system is written in Java, uses PostgreSQL for data storage, and runs on our Kubernetes cluster. We process around 50,000 transactions a day now.

[10:05 AM] New Dev: Wow, that's a lot.

[10:05 AM] Senior Dev: Yeah. So architecturally, it's pretty straightforward. You have the API layer that receives requests, a processing engine that handles the actual transaction logic, and then integrations with various payment gateways.

[10:06 AM] Senior Dev: One thing that's not obvious - we built in a retry mechanism with exponential backoff. This was critical because payment gateways can be flaky sometimes.

[10:07 AM] New Dev: That makes sense. How do you handle failures?

[10:07 AM] Senior Dev: Good question. We have a dead letter queue for transactions that fail after all retries. There's a monitoring dashboard - I'll send you the link - where you can see failed transactions and manually retry them if needed.

[10:08 AM] Senior Dev: The trickiest part is dealing with idempotency. You have to make sure that if someone accidentally submits the same payment twice, you only charge them once.

[10:09 AM] New Dev: How do you handle that?

[10:09 AM] Senior Dev: We use idempotency keys. Every transaction request must include a unique key. The system checks if we've seen that key before and returns the cached result if we have. The code for that is in the IdempotencyService class.

[10:10 AM] Senior Dev: Let me share the repo link... here you go. The main code is in the payments-service repo. The README has setup instructions.

[10:11 AM] New Dev: Got it. Who should I talk to if I have questions later?

[10:11 AM] Senior Dev: I'm your go-to for architecture questions. Sarah knows the payment gateway integrations really well - she dealt with all the API documentation headaches. And Mike handles the ops side, so anything about deployment or monitoring, talk to him.

[10:12 AM] Senior Dev: Oh, one more thing - there's a quirk with the test environment. You need to use special test card numbers that are documented in the wiki, otherwise transactions will fail. Caught me off guard when I first started.

[10:13 AM] New Dev: Good to know! I'll make sure to check that.

[10:13 AM] Senior Dev: Any questions before we wrap up?

[10:14 AM] New Dev: I think I'm good for now. This was really helpful!

[10:14 AM] Senior Dev: Cool. Feel free to ping me anytime. Let's schedule another session next week to go deeper into the gateway integrations?

[10:15 AM] New Dev: Sounds great!
```

**Meeti-Advanced Output:**
```markdown
# Knowledge Transfer: Payment Processing System

**Date:** [Date from context]
**Duration:** 15 minutes
**Led by:** Senior Dev
**Attendees:** Senior Dev, New Dev

## Session Goal

Provide comprehensive overview of the payment processing system architecture, key components, operational considerations, and critical knowledge for new team member onboarding.

## Knowledge Transfer Summary

### Historical Context

**Technology Perspective**
The payment processing system was built two years ago to replace a third-party solution. The system is implemented in Java with PostgreSQL for data persistence and runs on the Kubernetes cluster. It currently handles approximately 50,000 transactions daily. The migration from Stripe to an in-house solution was driven by cost considerations at scale and the need for greater technical control.

**Product Perspective**
The decision to build an in-house payment system was influenced by volume economics and product requirements for greater flexibility in supporting multiple payment methods. The product team needed capabilities that weren't available or practical with third-party solutions at the company's transaction scale.

**People Perspective**
The system was originally built by Senior Dev (architecture), Sarah (payment gateway integrations), and Mike (operations and deployment). These remain the primary contacts for different aspects of the system.

### Technical Deep Dive

**Architecture Overview**
The system follows a three-layer architecture:
1. **API Layer:** Receives and validates payment transaction requests
2. **Processing Engine:** Handles core transaction logic and orchestration
3. **Gateway Integrations:** Connects to various third-party payment providers

**Technology Stack**
- **Language:** Java
- **Database:** PostgreSQL
- **Infrastructure:** Kubernetes cluster
- **Scale:** ~50,000 transactions per day

**Key Technical Patterns**

**Retry Mechanism:** Built-in retry logic with exponential backoff to handle temporary payment gateway failures. Payment gateways can experience intermittent issues, and the retry mechanism ensures transaction success despite temporary connectivity or gateway problems.

**Idempotency Handling:** Critical feature ensuring duplicate payment prevention. Every transaction request must include a unique idempotency key. The system checks for previously seen keys and returns cached results for duplicate submissions. Implementation is in the IdempotencyService class.

**Failure Handling:** Failed transactions after all retry attempts are sent to a dead letter queue for manual review and potential retry via monitoring dashboard.

### Tips, Tricks & Friction Points

**Best Practices**
- Always include idempotency keys in transaction requests to prevent duplicate charges
- Monitor the dashboard regularly for failed transactions in the dead letter queue
- Use exponential backoff retry mechanism for transient gateway failures

**Common Friction Points**
- **Payment Gateway Reliability:** Payment gateways can be unreliable and experience intermittent failures. The retry mechanism is essential for handling these situations gracefully
- **Test Environment Card Numbers:** The test environment requires special card numbers documented in the wiki. Using incorrect card numbers will cause transaction failures during testing and development

**Gotchas to Avoid**
- Forgetting to include idempotency keys can result in duplicate charges if requests are accidentally resubmitted
- Not checking the wiki for test card numbers before working in test environment will lead to confusing transaction failures

### Resources & References

**Documentation**
- Monitoring dashboard: [Link to be shared]
- Test card numbers: Documented in company wiki

**Code Repositories**
- **payments-service repo:** Main codebase with setup instructions in README

**Key Contacts**
- **Senior Dev:** Architecture questions and overall system design
- **Sarah:** Payment gateway integrations and API documentation
- **Mike:** Operations, deployment, and monitoring

**Additional Resources**
- IdempotencyService class: Core implementation of duplicate prevention logic

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| Send monitoring dashboard link | Senior Dev | TBD |
| Review payments-service repo and README | New Dev | Before next session |
| Check wiki for test card numbers | New Dev | Before testing |
| Schedule follow-up session on gateway integrations | Senior Dev & New Dev | Next week |

## Questions & Clarifications Needed

- Deeper dive into gateway integrations planned for next session
```

---

## Example: Stand-up Meeting

**Input Transcript:**
```
[9:00 AM] Scrum Master: Good morning team! Let's do our stand-up. Alex, want to start?

[9:00 AM] Alex: Sure. Yesterday I wrapped up the user authentication refactoring. Today I'm starting on the API rate limiting feature. No blockers.

[9:01 AM] Scrum Master: Nice! Jordan?

[9:01 AM] Jordan: Um, I'm still working on the database migration script. It's taking longer than expected because I found some data inconsistencies that need to be cleaned up first. I might need help understanding the old schema.

[9:02 AM] Alex: I can help with that! I worked on that system last year. Want to sync after standup?

[9:02 AM] Jordan: That would be great, thanks!

[9:03 AM] Scrum Master: Perfect. Sam, how about you?

[9:03 AM] Sam: Yesterday I finished the UI components for the dashboard. Today I'm blocked though - I need the API endpoints that Alex is working on to be ready before I can integrate.

[9:04 AM] Alex: Oh, the rate limiting endpoints? Those won't be done until Thursday at least.

[9:04 AM] Sam: Hmm, that's later than I thought. That pushes my timeline back.

[9:05 AM] Scrum Master: Let's chat after standup about reprioritizing your work, Sam. Maybe you can pick up something else in the meantime?

[9:05 AM] Sam: Yeah, that makes sense.

[9:06 AM] Scrum Master: Anything else from anyone?

[9:06 AM] Jordan: Just wondering - are we still planning to demo this sprint's work on Friday?

[9:07 AM] Scrum Master: Good question. Let me confirm with the product team and get back to everyone. Anything else?

[9:07 AM] Team: Nope, all good!

[9:08 AM] Scrum Master: Great, thanks everyone!
```

**Meeti-Advanced Output:**
```markdown
# Daily Team Stand-up

**Date:** [Date from context]
**Duration:** 8 minutes
**Attendees:** Scrum Master, Alex, Jordan, Sam

## Stand-up Health Check: 🟡 YELLOW

**Health Status Reasoning:**
This stand-up receives a Yellow (OKish) status for the following reasons:
- One team member (Sam) discovered an unexpected dependency that blocks their planned work and pushes back their timeline
- Data inconsistencies found during Jordan's work were not previously known, suggesting some surprise technical issues
- Good team collaboration (Alex offering to help Jordan) but overall indicates some planning gaps
- Sprint demo status is unclear, adding uncertainty to team goals
- While the stand-up was efficient and blockers are being addressed, the unexpected dependencies and timeline impacts indicate less-than-ideal team alignment and planning

## Meeting Goal

Quick daily synchronization to share progress updates, identify blockers, and coordinate team activities.

## Discussion Summary

### Individual Updates

**Alex**
- **Completed:** User authentication refactoring
- **In Progress:** Starting API rate limiting feature
- **Notes:** Rate limiting endpoints expected to be complete by Thursday

**Jordan**
- **Completed:** Continued work on database migration script
- **In Progress:** Still working on database migration, taking longer than expected
- **Notes:** Found unexpected data inconsistencies requiring cleanup before proceeding. Needs help understanding old database schema

**Sam**
- **Completed:** UI components for dashboard
- **In Progress:** Blocked waiting for API endpoints
- **Notes:** Expected API endpoints won't be ready until Thursday, which pushes Sam's timeline back

### Team Collaboration Highlights

- **Alex helped Jordan:** Alex offered to help Jordan understand the old database schema, having worked on that system last year. Sync scheduled for after stand-up

## Blockers & Dependencies

- **Sam blocked by API dependencies:** Sam cannot integrate dashboard UI components until Alex completes rate limiting API endpoints (expected Thursday). This dependency was not previously known and pushes Sam's timeline back
- **Data inconsistencies in database migration:** Jordan discovered data inconsistencies that must be cleaned up before completing the migration script, extending the timeline

## Concerns Raised

- **Timeline impact for Sam:** Unexpected delay in API endpoint availability pushes back Sam's integration work
- **Sprint demo uncertainty:** Team is unsure if sprint demo is still scheduled for Friday, creating ambiguity about sprint goals

## Action Items

| Action Item | Owner | Due Date |
|-------------|-------|----------|
| Complete API rate limiting feature | Alex | Thursday |
| Sync with Jordan on old database schema | Alex | After stand-up |
| Confirm sprint demo schedule with product team | Scrum Master | TBD |
| Discuss work reprioritization with Sam | Scrum Master | After stand-up |
| Continue database migration with data cleanup | Jordan | TBD |

## Parking Lot

- Work reprioritization for Sam while waiting for API dependencies (to be discussed after stand-up)
- Sprint demo confirmation and scheduling details
```

---

## Tips for Best Results

1. **Let the meeting type drive the format:** Don't force a 1-1 template onto a knowledge transfer session
2. **Capture context, not just content:** Especially for knowledge transfers, why something exists is as important as what it is
3. **Be realistic with health checks:** Don't inflate stand-up health status - honest assessment helps teams improve
4. **Use TBD liberally:** Better to capture an action item with TBD owner than lose it entirely
5. **Reorganize, don't regurgitate:** Transform vague statements into clear, actionable items
6. **Focus on utility:** These notes should be useful references, not just meeting records
